# Calorias

App de controle de calorias, macros, água e peso. Funciona sem internet depois da primeira abertura e pode ser instalado no celular como um aplicativo. Não usa IA nem servidor: a busca de alimentos é feita em uma tabela que já vem dentro do app (`foods.js`).

## Arquivos

Mantenha todos juntos na mesma pasta, sem subpastas:

- `index.html`: o app
- `foods.js`: tabela de alimentos
- `manifest.webmanifest` e `sw.js`: instalação e modo offline
- `icon-192.png`, `icon-512.png`, `icon-maskable-512.png` e `apple-touch-icon.png`: ícones

## Publicar no GitHub Pages

1. Crie um repositório novo no GitHub (por exemplo `calorias`).
2. Envie todos os arquivos para a raiz do repositório (botão **Add file > Upload files**).
3. Abra **Settings > Pages**. Em **Build and deployment**, escolha **Deploy from a branch**, branch `main` e pasta `/ (root)`. Salve.
4. Aguarde um minuto. O endereço será `https://SEU-USUARIO.github.io/calorias/`.

## Instalar no celular

- **iPhone (Safari):** abra o endereço, toque em Compartilhar e depois em **Adicionar à Tela de Início**.
- **Android (Chrome):** abra o endereço, toque no menu (três pontinhos) e em **Instalar app** ou **Adicionar à tela inicial**.

## Seus dados

Tudo fica guardado só no aparelho (armazenamento do navegador). Não há sincronização entre aparelhos. Use **Ajustes > Salvar backup** de vez em quando e **Restaurar backup** para levar os dados para outro aparelho.

## Atualizar o app

Ao trocar qualquer arquivo no GitHub, aumente o número da versão em `sw.js` (`const CACHE = 'calorias-v1'` para `'calorias-v2'`). Assim os aparelhos baixam a versão nova.

## Sobre a tabela de alimentos

São mais de 350 alimentos com valores aproximados por 100 g, de quatro origens indicadas em cada item: TACO (tabela brasileira da Unicamp), USDA, rótulo médio de industrializados e receita caseira média. Os valores foram reunidos como referência e **não são uma cópia oficial** dessas tabelas: para precisão, confira o rótulo do produto ou a TACO oficial.

Para acrescentar alimentos, use **Ajustes > Meus alimentos** (um por vez ou importando um CSV com `nome;kcal;proteína;carboidrato;gordura` por 100 g). Quem edita código pode também acrescentar linhas em `foods.js`, seguindo o formato descrito no topo do arquivo.

As estimativas de gasto e meta são aproximadas e não substituem um nutricionista ou médico.
